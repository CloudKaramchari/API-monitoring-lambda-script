import json
import os
import urllib3
import boto3

#SESclient = boto3.client('ses',region_name='ap-south-1')
Region = os.environ['Region']
API_Name = os.environ['API_Name']
URL = os.environ['URL']
ARN = os.environ['ARN']
client = boto3.client('sns', region_name=Region)
cloudwatch = boto3.client('cloudwatch', region_name=Region)

def lambda_handler(event, context):
    http = urllib3.PoolManager()
    r = http.request('GET', URL)
    r.data
    webStatus = r.status
    #print (r.data)
    if webStatus == 200 :
       print ("Website is UP")
       cloudwatch.put_metric_data(
                        MetricData = [
                                        {
                                            'MetricName': 'API-Monitoring',
                                            'Dimensions': [
                                                {
                                                    'Name': 'API-Name',
                                                    'Value': API_Name
                                                }
                                            ],
                                            'Unit': 'None',
                                            'Value': 1
                                        },
                                    ],
                    Namespace='API-Monitoring'
                )
    else :
        print ("Website is Down with status code: "+ str(webStatus))
        cloudwatch.put_metric_data(
                    MetricData = [
                                    {
                                        'MetricName': 'API-Monitoring',
                                        'Dimensions': [
                                            {
                                                'Name': 'API-Name',
                                                'Value': API_Name
                                            }
                                        ],
                                        'Unit': 'None',
                                        'Value': 0
                                    },
                                ],
                Namespace='API-Monitoring'
            )
        response = client.publish(
                                    TargetArn= ARN,
                                    Subject="Alert: "+API_Name+" Application",
                                    Message="Application "+ URL +" is down with "+str(webStatus)+" Status Code."
                                )
                                       